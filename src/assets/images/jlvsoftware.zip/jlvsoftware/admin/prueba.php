<?php
   $mensaje = "<br>Hola";
  echo $mensaje;
?>