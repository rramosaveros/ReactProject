<?php
    $hostname = 'localhost';
    $database = 'cueroselalcecom_SURTIMAX';
    $username = 'cueroselalcecom_surtimax_root';
    $password = 'W24~uK_dH(N[';
?>